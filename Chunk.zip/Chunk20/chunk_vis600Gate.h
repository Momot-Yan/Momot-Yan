#pragma once

#include "chunk_defs.h"
#include "chunk_utils.h"

namespace chunk
{
  /*
  template<> inline void WriteChunk<::math::Vector3f>(ChunkNode* pNode, const char* itemName, math::Vector3f const& val)
  {
  chunk::Vector3f v;
  v.x = val.x;
  v.y = val.y;
  v.z = val.z;
  WriteChunk( pNode, itemName, v );
  }

  template<> inline void WriteChunk<math::Color4f>(ChunkNode* pNode, const char* itemName,    math::Color4f  const& val)
  {
  chunk::Color4f v;
  v.r = val.r;
  v.g = val.g;
  v.b = val.b;
  v.a = val.a;
  WriteChunk( pNode, itemName, v );
  }*/

  //    template<> void WriteChunk<math::Vector2f  >(ChunkNode* pNode, const char* itemName, math::Vector2f const& val);
  //    template<> void WriteChunk<math::Vector3d  >(ChunkNode* pNode, const char* itemName, math::Vector3d const& val);
  //    template<> void WriteChunk<math::Vector4f  >(ChunkNode* pNode, const char* itemName, math::Vector4f const& val);
  /*template<> inline void WriteChunk<math::Angles    >(ChunkNode* pNode, const char* itemName, math::Angles  const& val)
  {
  chunk::Angles v;
  v.yaw   = val.yaw;
  v.pitch = val.pitch;
  v.roll  = val.roll;
  WriteChunk( pNode, itemName, v );
  }*/
}
