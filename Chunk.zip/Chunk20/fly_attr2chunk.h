#pragma once
#include <assert.h>

namespace manta
{

  class CommonPartExporter
  {
  //public:
  //  void SetSimpleProperty(chunk::ChunkNode* pEntityNode, std::wstring name, const fly_item * pItem, const fly_attrs_w& attrs)
  //  {
  //     chunk::ChunkNode* pPropNode = pEntityNode->AddNode("properties");
  //     assert(pPropNode->isGood());
  //  
  //     /*switch (pItem->ft)
  //     {
  //     case fly_item::FL_CHAR:
  //        chunk::WriteChunk(pPropNode, name, pItem->char_val );
  //        break;
  //     case fly_item::FL_BYTE:
  //        chunk::WriteChunk(pPropNode, name, pItem->byte_val);
  //        break;
  //     case fly_item::FL_SHORT:
  //        chunk::WriteChunk(pPropNode, name, pItem->short_val);
  //        break;
  //     case fly_item::FL_INT:
  //        chunk::WriteChunk(pPropNode, name, pItem->int_val);
  //        break;
  //     case fly_item::FL_DWORD:
  //        chunk::WriteChunk(pPropNode, name, (int32)pItem->dword_val);
  //        break;
  //     case fly_item::FL_FLOAT:
  //        chunk::WriteChunk(pPropNode, name, pItem->float_val);
  //        break;
  //     case fly_item::FL_DOUBLE:
  //        chunk::WriteChunk(pPropNode, name, pItem->double_val);
  //        break;
  //     case fly_item::FL_BOOL:
  //        chunk::WriteChunk(pPropNode, name, pItem->int_val != 0);
  //        break;
  //     case fly_item::FL_STRING_W:
  //        chunk::WriteChunk(pPropNode, name, (const char*)attrs.get_item(name, L"") );
  //        break;
  //     }*/
  //  }

  //  void SetAnglesProperty(chunk::ChunkNode* pEntityNode, std::wstring name, const fly_attrs_w & angAttr)
  //  {
  //     chunk::ChunkNode* pPropNode = pEntityNode->AddNode("properties");
  //     assert(pPropNode->isGood());
  //  
  //     chunk::Angles ang((float)angAttr.get_item<double>(L"Heading", 0.0),
  //        (float)angAttr.get_item<double>(L"Pitch", 0.0),
  //        (float)angAttr.get_item<double>(L"Roll", 0.0));
  //     //chunk::WriteChunk(pPropNode, name, ang);
  //  }

  //   void SetEnumProperty(chunk::ChunkNode* pEntityNode, std::wstring name, DWORD dwordVal, LPCWSTR strVal)
  //   {
  //      chunk::ChunkNode* pPropNode = pEntityNode->AddNode("properties");
  //      assert(pPropNode->isGood());
  //   
  //      /*if (0 == _wcsicmp(L"predefinedShader", name))
  //      {
  //         if (0 == _wcsicmp(L"Smoke", strVal))
  //            chunk::WriteChunk(pPropNode, "shaderFileName", std::string("renderer/si/particles/smoke.si"));
  //         else if (0 == _wcsicmp(L"Fire", strVal))
  //            chunk::WriteChunk(pPropNode, "shaderFileName", std::string("renderer/si/particles/fire.si"));
  //         else if (0 == _wcsicmp(L"Explosion", strVal))
  //            chunk::WriteChunk(pPropNode, "shaderFileName", std::string("renderer/si/particles/explosion.si"));
  //         else if (0 == _wcsicmp(L"Explosion Fire", strVal))
  //            chunk::WriteChunk(pPropNode, "shaderFileName", std::string("renderer/si/particles/explosion_fire.si"));
  //         else if (0 == _wcsicmp(L"Colored Smoke", strVal))
  //            chunk::WriteChunk(pPropNode, "shaderFileName", std::string("renderer/si/particles/colored_smoke.si"));
  //         else if (0 == _wcsicmp(L"Parts", strVal))
  //            chunk::WriteChunk(pPropNode, "shaderFileName", std::string("renderer/si/particles/parts.si"));
  //         else if (0 == _wcsicmp(L"Trail", strVal))
  //            chunk::WriteChunk(pPropNode, "shaderFileName", std::string("renderer/si/particles/trail.si"));
  //         else if (0 == _wcsicmp(L"Puffs", strVal))
  //            chunk::WriteChunk(pPropNode, "shaderFileName", std::string("renderer/si/particles/puffs.si"));
  //         else
  //            assert(!"Unknown predefinedShader");
  //      }
  //      else
  //      {
  //         assert(!"Unknown enum type");
  //      }*/
  //   }
    };

  } // namespace manta