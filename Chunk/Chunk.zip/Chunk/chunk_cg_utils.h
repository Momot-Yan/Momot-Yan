#pragma once
#include "chunk_defs.h"
#include "chunk.h"

namespace chunk
{/*
 template<> inline void WriteChunk<cg::cprf   >(ChunkNode* pNode, const char* itemName, cg::cprf const & val );
 template<> inline void WriteChunk<cg::point_3>(ChunkNode* pNode, const char* itemName, cg::point_3  const& val);*/
}

#include "chunk_cg_utils.inl"